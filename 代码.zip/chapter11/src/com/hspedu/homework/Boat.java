package com.hspedu.homework;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class Boat implements Vehicles {
    @Override
    public void work() {
        System.out.println(" 过河的时候，使用小船.. ");
    }
}
