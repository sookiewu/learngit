package com.hspedu.homework;

/**
 * @author 韩顺平
 * @version 1.0
 */
public interface Vehicles {
    //有一个交通工具接口类Vehicles，有work接口
    public void work();
}
