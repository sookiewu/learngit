package com.hspedu;

/**
 * @author 韩顺平
 * @version 1.0
 * 节点流
 */
public class FileReader_ extends Reader_ {

        public void readFile() {
        System.out.println("对文件进行读取...");
    }



}
