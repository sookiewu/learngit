package com.hspedu.outputstream_;

import java.io.Serializable;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class Master implements Serializable {
}
