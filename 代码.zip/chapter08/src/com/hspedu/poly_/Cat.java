package com.hspedu.poly_;

public class Cat extends Animal {
    public Cat(String name) {
        super(name);
    }
}
