package com.hspedu.poly_;

public class Bone extends Food {
    public Bone(String name) {
        super(name);
    }
}
