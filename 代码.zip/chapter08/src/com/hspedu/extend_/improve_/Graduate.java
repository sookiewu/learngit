package com.hspedu.extend_.improve_;

public class Graduate extends Student {

    public void testing() {//和Pupil不一样
        System.out.println("大学生 " + name + " 正在考大学数学..");
    }
}
