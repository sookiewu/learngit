package com.hspedu.override_;

public class Override01 {
    public static void main(String[] args) {
        //演示方法重写的情况
        Dog dog = new Dog();
        dog.cry();//ctrl+b
    }
}

