package com.hspedu.super_;

public class Super01 {
    public static void main(String[] args) {
        B b = new B();//子类对象
        //b.sum();
        b.test();
    }
}

