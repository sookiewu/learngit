package com.hspedu.super_;

public class Base { //父类是Object

    public int n1 = 999;
    public int age = 111;
    public void cal() {
        System.out.println("Base类的cal() 方法...");
    }
    public void eat() {
        System.out.println("Base类的eat().....");
    }
}
