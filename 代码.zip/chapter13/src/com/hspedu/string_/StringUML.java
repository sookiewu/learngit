package com.hspedu.string_;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class StringUML {
    public static void main(String[] args) {
        //String
    }
}
