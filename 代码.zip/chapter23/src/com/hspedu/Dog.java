package com.hspedu;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class Dog {
}
