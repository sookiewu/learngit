package com.hspedu.reflection.classload_;

import com.hspedu.Cat;

/**
 * @author 韩顺平
 * @version 1.0
 */
public class Test {
    public static void main(String[] args) {

        Cat cat = new Cat();

    }
}
